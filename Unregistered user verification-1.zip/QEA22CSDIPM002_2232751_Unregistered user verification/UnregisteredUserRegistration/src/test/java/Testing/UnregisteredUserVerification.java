package Testing;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;


public class UnregisteredUserVerification
{
static WebDriver driver;

//Setup for Chrome Browser
public static void chromeBrowser()
{
System.setProperty("webdriver.chrome.driver","C:\\Users\\Lenovo\\Desktop\\QEA22CSDIPM002_2232751_Unregistered user verification\\UnregisteredUserRegistration\\chromedriver.exe");
driver=new ChromeDriver();
}

//Setup for Edge Browser
public static void edgeBrowser()
{
System.setProperty("webdriver.edge.driver","C:\\Users\\Lenovo\\Desktop\\QEA22CSDIPM002_2232751_Unregistered user verification\\UnregisteredUserRegistration\\msedgedriver.exe");
driver=new EdgeDriver();
}
public static void main(String[] args) throws InterruptedException
{

//select browser
System.out.println("Select your browser 1.chrome 2.Edge");
@SuppressWarnings("resource")
Scanner sc=new Scanner(System.in);
int choice=sc.nextInt();
if(choice==1)
chromeBrowser();
else
edgeBrowser();

//Launch Browser
driver.get("http://change2naturalfoods.com/");

//maximizing the window
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

//click login/Register  button
WebElement regBtn=driver.findElement(By.linkText("Login/Register"));
regBtn.click();

//click the email and enter email "jobspari2@gmail.com"
driver.findElement(By.id("email")).sendKeys("jobspari2@gmail.com");

//Using sleep statement
Thread.sleep(2000);

//click on  password and enter password "abc258"
driver.findElement(By.id("password")).sendKeys("abc258");
   
//Using sleep statement
Thread.sleep(2000);
 
//click on login button
WebElement goBtn=driver.findElement(By.xpath("//button[contains(text(),'Login')]"));
goBtn.click();

//Using sleep statement
Thread.sleep(2000);
 
//verify error message
WebElement alt=driver.findElement(By.cssSelector("div[role='alert']"));
System.out.println(alt.getText());

//Using sleep Statement
Thread.sleep(2000);

//closing browser
driver.close();
}
}


